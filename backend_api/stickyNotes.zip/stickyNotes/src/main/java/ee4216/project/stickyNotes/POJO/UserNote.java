/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ee4216.project.stickyNotes.POJO;

import java.util.List;

/**
 *
 * @author wuzijian
 */
public class UserNote {
    private String UserId;
    private String status;
    private String description;
    private List<NoteDescription> NoteList;

    /**
     * @return the UserId
     */
    public String getUserId() {
        return UserId;
    }

    /**
     * @param UserId the UserId to set
     */
    public void setUserId(String UserId) {
        this.UserId = UserId;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the NoteList
     */
    public List<NoteDescription> getNoteList() {
        return NoteList;
    }

    /**
     * @param NoteList the NoteList to set
     */
    public void setNoteList(List<NoteDescription> NoteList) {
        this.NoteList = NoteList;
    }
    
    
}
