/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ee4216.project.stickyNotes.POJO;

/**
 *
 * @author wuzijian
 */
public class AuthentifyRequest {
    private String request;
    private String username;
    private String password;
    private String email;
    
    public void setRequest(String prequest)
    {
        this.request = prequest;
    }
    
    public String getRequest()
    {
        return request;
    }
    
    public void setUsername(String pusername)
    {
        this.username = pusername;
    }
    
    public String getUsername()
    {
        return username;
    }
    
    public void setPassword(String pPassword)
    {
        this.password = pPassword;
    }
    
    public String getPassword()
    {
        return password;
    }
    
    public void setEmail(String pemail)
    {
        this.email = pemail;
    }
    
    public String getEmail()
    {
        return email;
    }
}
