/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ee4216.project.stickyNotes.controller;

import ee4216.project.stickyNotes.DAO.BaseDAO;
import ee4216.project.stickyNotes.POJO.AuthentifyRequest;
import ee4216.project.stickyNotes.POJO.BaseResponse;
import ee4216.project.stickyNotes.POJO.NoteDescription;
import ee4216.project.stickyNotes.POJO.UserNote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author wuzijian
 */

@RestController
@CrossOrigin
@RequestMapping(path="/api")  
public class RestfulController 
{
    private String userId = "";
    private String description = "Successful";
    private String status = "200";
    
    
    @Autowired
    BaseDAO lvBaseDAO;
    
    // sign in and sign up
    @PostMapping("/authentify")
    public UserNote authentifyUser(@RequestBody(required=false) AuthentifyRequest requestDetails)
    {
       UserNote lvUserNote = new UserNote();
       String lvRequest = requestDetails.getRequest();
       String lvUsername = requestDetails.getUsername();
       String lvPassword = requestDetails.getPassword();
       String lvEmail = requestDetails.getEmail();
       
       boolean lvUserExist = lvBaseDAO.queryExistUserInfo(lvUsername, lvPassword);
       
       lvUserNote.setUserId(lvUsername);
       
       // check if user sign in or sign out
       if(lvRequest.equalsIgnoreCase("signin"))
       {
           // user doesn't exist based on sign in information
           if(lvUserExist == false)
           {
               lvUserNote.setStatus("300");
               lvUserNote.setDescription("User name or password is wrong, pleas check again");
               return lvUserNote;
           }
           
       }
       else if(lvRequest.equalsIgnoreCase("signup"))
       {
           // check if user exist in the table
           if(lvUserExist == true)
           {
               lvUserNote.setStatus("400");
               lvUserNote.setDescription("User has already exist, please change a name");
               return lvUserNote;
           }
           lvBaseDAO.registerUser(lvUsername, lvPassword, lvEmail);
           //lvBaseDAO.createDefaultNote(lvUsername);
       }
        
       // set the remaining properties
       lvUserNote.setStatus(status);
       lvUserNote.setDescription(description);
       
       lvUserNote.setNoteList(lvBaseDAO.queryNoteList(lvUsername));
       
       return lvUserNote;
    }
    
    
    // create new Note
    @PutMapping("/newNote/{user}")
    public BaseResponse createNote(@PathVariable String user, @RequestBody(required=false) NoteDescription pNoteDescription)
    {
        String lvuuid = lvBaseDAO.createNote(user, pNoteDescription);
        String lvstatus = "successful";
       
        if(lvuuid == null)
            lvstatus = "false";
            
        BaseResponse lvBaseResponse = new BaseResponse();
        lvBaseResponse.setStatus(lvstatus);
        lvBaseResponse.setUuid(lvuuid);
        
        return lvBaseResponse;
    }
    
    // Update Note
    
    
    // delete Note
    @DeleteMapping("/{id}")
    public BaseResponse deleteNote(@PathVariable String id)
    {
        String lvstatus = lvBaseDAO.deleteNote(id);
        
        BaseResponse lvBaseResponse = new BaseResponse();
        lvBaseResponse.setStatus(lvstatus);
        
        return lvBaseResponse;
    }
    
    
    // update
    @PostMapping("/save")
    public BaseResponse updateNote(@RequestBody(required=false) NoteDescription pNoteDescription)
    {
        String lvstatus = lvBaseDAO.updateNote(pNoteDescription);
        
        BaseResponse lvBaseResponse = new BaseResponse();
        lvBaseResponse.setStatus(lvstatus);
        
        return lvBaseResponse;
    }
}
