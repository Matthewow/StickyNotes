/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ee4216.project.stickyNotes.POJO;

/**
 *
 * @author wuzijian
 */

public class NoteDescription {
    private String noteId;
    private String title;
    private String content;
    private String backcolor;
    private String font;

    /**
     * @return the noteId
     */
    public String getNoteId() {
        return noteId;
    }

    /**
     * @param noteId the noteId to set
     */
    public void setNoteId(String noteId) {
        this.noteId = noteId;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * @return the backcolor
     */
    public String getBackcolor() {
        return backcolor;
    }

    /**
     * @param backcolor the backcolor to set
     */
    public void setBackcolor(String backcolor) {
        this.backcolor = backcolor;
    }

    /**
     * @return the font
     */
    public String getFont() {
        return font;
    }

    /**
     * @param font the font to set
     */
    public void setFont(String font) {
        this.font = font;
    }


            
}
