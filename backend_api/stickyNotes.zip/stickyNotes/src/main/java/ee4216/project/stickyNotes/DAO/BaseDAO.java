/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ee4216.project.stickyNotes.DAO;

import ee4216.project.stickyNotes.POJO.NoteDescription;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

/**
 *
 * @author wuzijian
 */

@Repository("BaseDAO")
public class BaseDAO {
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    public boolean queryExistUserInfo(String pName, String pPassword)
    {
        String lvSql = "SELECT COUNT(*) FROM USERINFO WHERE USERNAME = ? AND PASSWORD = ?";
        int count = jdbcTemplate.queryForObject(lvSql, new Object[]{pName, pPassword}, Integer.class);
        
        return count != 0;
    }
    
    public void registerUser(String pUsername, String pPassword, String pEmail)
    {
        String lvSql = "INSERT INTO USERINFO (USERNAME, PASSWORD, EMAIL) VALUES (?, ?, ?)";
        
        jdbcTemplate.update(lvSql, new Object[]{pUsername, pPassword, pEmail});
    }
    
    public void createDefaultNote(String pUserName)
    {   
        String lvNoteId = UUID.randomUUID().toString();
        String lvtitle = "";
        String lvcontent = "";
        String lvFontColor = "yellow";
        String lvFontSize = "12";
        
        String lvSql = "INSERT INTO NOTETABLE (USERID, NOTEID, CONTENT, BACKCOLOR, FONTSIZE, TITLE)"
                + " VALUES (?, ?, ?, ?, ?, ?)";
        
        jdbcTemplate.update(lvSql, new Object[]{pUserName, lvNoteId, lvcontent, lvFontColor, lvFontSize, lvtitle});

    }
    
    public List<NoteDescription> queryNoteList(String pUserName)
    {
        List<NoteDescription> lvNoteDescriptions = new ArrayList<>();
        String lvSql = "SELECT * FROM NOTETABLE WHERE USERID = ?";
        
        lvNoteDescriptions = jdbcTemplate.query(lvSql, new Object[]{pUserName}, new noteMapper());
        return lvNoteDescriptions;
    }
    
    public NoteDescription queryNote(String pUsername, String pNoteID)
    {
        String lvSql = "SELECT * FROM NOTETABLE WHERE USERID = ? AND NOTEID = ?";
        NoteDescription lvnoteDescription = jdbcTemplate.queryForObject(lvSql, new noteMapper(), new Object[]{pUsername, pNoteID});
        
        return lvnoteDescription;
    }
    
    public String deleteNote(String pNoteId)
    {
        String Sql = "DELETE FROM NOTETABLE WHERE NOTEID = ? ";
        int row = jdbcTemplate.update(Sql, new Object[]{pNoteId});
        
        if(row == 0)
            return "fail";
        return "successful";
    }
    
    public String createNote(String pUsername, NoteDescription lvNoteDescription)
    {
        String lvNoteId = lvNoteDescription.getNoteId();
        
        String lvtitle = lvNoteDescription.getTitle();
        String lvcontent = lvNoteDescription.getContent();
        String lvBackColor = lvNoteDescription.getBackcolor();
        String lvFontSize = lvNoteDescription.getFont();
        
        String lvSql = "INSERT INTO NOTETABLE (USERID, NOTEID, CONTENT, BACKCOLOR, FONTSIZE, TITLE) VALUES (?, ?, ?, ?, ?, ?)";
        
        jdbcTemplate.update(lvSql, new Object[]{pUsername, lvNoteId, lvcontent, lvBackColor, lvFontSize, lvtitle});
        
        return lvNoteId;
    }
    
    public String updateNote(NoteDescription lvNoteDescription)
    {
        String lvContent = lvNoteDescription.getContent();
        String lvfontsize = lvNoteDescription.getFont();
        String lvBackColor = lvNoteDescription.getBackcolor();
        String lvNoteId = lvNoteDescription.getNoteId();
        String lvTitle = lvNoteDescription.getTitle();
        String lvSql = "UPDATE NOTETABLE SET CONTENT = ?, FONTSIZE = ?, BACKCOLOR = ?, TITLE = ? " 
                + "WHERE NOTEID = ?";
        
        int row = jdbcTemplate.update(lvSql, new Object[]{lvContent, lvfontsize, lvBackColor, lvTitle, lvNoteId});
        
        System.out.println(row);
        
        if(row == 0)
            return "fail";
        
        return "successful";
    }
    
    private static class noteMapper implements RowMapper<NoteDescription>
    {

        @Override
        public NoteDescription mapRow(ResultSet rs, int i) throws SQLException 
        {
            NoteDescription lvNoteDescription = new NoteDescription();
            lvNoteDescription.setNoteId(rs.getString("NOTEID"));
            lvNoteDescription.setTitle(rs.getString("TITLE"));
            lvNoteDescription.setContent(rs.getString("CONTENT"));
            lvNoteDescription.setBackcolor(rs.getString("BACKCOLOR"));
            lvNoteDescription.setFont(rs.getString("FONTSIZE"));
            return  lvNoteDescription;
        }
        
    }
    
}

