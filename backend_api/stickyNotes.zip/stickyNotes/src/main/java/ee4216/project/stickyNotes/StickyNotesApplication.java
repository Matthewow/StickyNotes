package ee4216.project.stickyNotes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StickyNotesApplication {

	public static void main(String[] args) {
		SpringApplication.run(StickyNotesApplication.class, args);
	}

}
