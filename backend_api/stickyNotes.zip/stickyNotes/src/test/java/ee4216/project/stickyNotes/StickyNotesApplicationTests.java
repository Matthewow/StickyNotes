package ee4216.project.stickyNotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StickyNotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
